import os
import shutil
import pathlib


# Function to perform the installation
def install_app():
    # Get the path to the Saved Games folder
    saved_games_path = pathlib.Path.home() / 'Saved Games'

    # Prompt the user for installation directory or use Saved Games folder as default
    install_path = saved_games_path

    # Create the installation directory if it doesn't exist
    os.makedirs(install_path, exist_ok=True)

    # Unzip your app files to the installation directory (assuming your app files are in a ZIP file)
    app_zip_path = 'Dungeon Men.zip'
    shutil.unpack_archive(app_zip_path, install_path)

    # Remove the original ZIP file if needed
    os.remove(app_zip_path)

    # Create a desktop shortcut for the app
    app_executable_path = f'{install_path}/Dungeon Men/main.exe'  # Replace 'main.exe' with the actual executable name

    print('Installation completed successfully.')


if __name__ == "__main__":
    # Run the installation
    install_app()
